export default [
  {
    id: '0',
    description: 'Tenerife, Canary Islands',
  },
  {
    id: '1',
    description: 'Tenerife, Santa Cruz de Tenerife',
  },
  {
    id: '2',
    description: 'Tenerife, El Medano',
  },
  {
    id: '3',
    description: 'Tenerife, Costa Adeje',
  },
  {
    id: '4',
    description: 'Tenerife, Puerto de la Cruz',
  },
];
